## Nier Automata

### A theme for T-UI Expert Launcher inspired by the game NieR: Automata.

**Features:**
* `chwf`: A script to easily customize weather data.
* `sysinfo`: Display system information with an ascii art logo.
* 2B wallpaper.
* Weather status
* Icons for Battery, WiFi, Data, IP, RAM, and  internal storage
* Font: Fira Code Mono
